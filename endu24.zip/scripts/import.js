import dotenv from 'dotenv'
dotenv.config({ path: '.env.local' })

import fs from 'fs'
import csv from 'csv-parser'
import { createClient } from '@supabase/supabase-js'
import slugify from 'slugify'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
)

// 🔥 funzione mapping categoria
async function getCategoryId(row) {
  const title = row['Title']?.toLowerCase() || ''

  let slug = 'accessori' // default

  if (title.includes('casco')) slug = 'caschi'
  else if (title.includes('giacca')) slug = 'giacche'
  else if (title.includes('guanti')) slug = 'guanti'
  else if (title.includes('borsa') || title.includes('valigia')) slug = 'valigie-borse'
  else if (title.includes('gps') || title.includes('telecamera')) slug = 'elettronica'

  const { data } = await supabase
    .from('categories')
    .select('id')
    .eq('slug', slug)
    .single()

  return data?.id || null
}

const results = []

fs.createReadStream('data/products_export.csv')
  .pipe(csv())
  .on('data', (row) => results.push(row))
  .on('end', async () => {

    for (const r of results) {

      const name = r['Title']
      const slug = r['Handle']
      const brandName = r['Vendor']
      const image = r['Image Src']
      const price = parseFloat(r['Variant Price'])

      if (!name || !slug) continue

      // 🔥 CATEGORY
      const category_id = await getCategoryId(r)

      // 🔥 BRAND
      let { data: brand } = await supabase
        .from('brands')
        .select('*')
        .eq('name', brandName)
        .single()

      if (!brand) {
        const { data: newBrand } = await supabase
          .from('brands')
          .insert({
            name: brandName,
            slug: slugify(brandName, { lower: true })
          })
          .select()
          .single()

        brand = newBrand
      }

      // 🔥 PRODUCT
      const { data: product } = await supabase
        .from('products')
        .insert({
          name,
          slug,
          image,
          brand_id: brand.id,
          category_id: category_id, // ✅ FIX QUI
          description: r['Body (HTML)']
        })
        .select()
        .single()

      // 🔥 OFFER
      await supabase
        .from('offers')
        .insert({
          product_id: product.id,
          store: 'Endurrad',
          price,
          url: `https://endurrad.com/products/${slug}`
        })

      console.log('✔ Importato:', name)
    }

    console.log('🚀 IMPORT COMPLETATO')
  })