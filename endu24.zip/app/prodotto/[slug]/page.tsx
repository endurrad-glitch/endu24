import { supabase } from '@/lib/supabase'

type PageProps = {
  params: Promise<{ slug: string }>
}

export default async function ProductPage({ params }: PageProps) {
  const { slug } = await params

  const { data, error } = await supabase
    .from('products')
    .select(`
      name,
      description,
      image,
      specs,
      brands (name),
      categories (name, slug),
      offers (store, price, url)
    `)
    .eq('slug', slug)
    .single()

  if (error || !data) {
    return (
      <main className="container page-section">
        <p>Prodotto non trovato.</p>
      </main>
    )
  }

  const offers = [...(data.offers || [])].sort(
    (a: any, b: any) => Number(a.price) - Number(b.price)
  )

  const bestOffer = offers[0]

  const brandName = Array.isArray(data.brands)
    ? data.brands[0]?.name
    : (data.brands as any)?.name

  const categoryName = Array.isArray(data.categories)
    ? data.categories[0]?.name
    : (data.categories as any)?.name

  return (
    <main className="container page-section">
      <section className="product-hero">
        <div className="product-media">
          <img
            src={data.image || 'https://placehold.co/800x800/f2f2f2/aaaaaa?text=Endu24'}
            alt={data.name}
          />
        </div>

        <div className="product-info">
          <div className="eyebrow">
            {brandName ? `${brandName}${categoryName ? ' · ' + categoryName : ''}` : categoryName}
          </div>

          <h1 className="product-title">{data.name}</h1>

          {data.description && (
            <p className="product-description">{data.description}</p>
          )}

          {bestOffer && (
            <div className="price-card">
              <p className="price-value">€{bestOffer.price}</p>
              <p className="price-meta">Miglior prezzo su {bestOffer.store}</p>
              <a
                href={bestOffer.url}
                target="_blank"
                rel="noreferrer"
                className="primary-button"
              >
                Acquista
              </a>
            </div>
          )}
        </div>
      </section>

      <section className="page-section" style={{ paddingTop: 56, paddingBottom: 0 }}>
        <h2 className="section-title">Specifiche</h2>
        <div className="specs-card">
          <div className="specs-grid">
            {Object.entries(data.specs || {}).map(([key, value]) => (
              <div className="spec-row" key={key}>
                <span className="spec-key">{key}</span>
                <span className="spec-value">{String(value)}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="page-section" style={{ paddingTop: 56, paddingBottom: 0 }}>
        <h2 className="section-title">Confronta prezzi</h2>
        <div className="offers-card">
          <div className="offers-list">
            {offers.map((offer: any, index: number) => (
              <div className="offer-row" key={`${offer.store}-${index}`}>
                <div className="offer-store">{offer.store}</div>
                <div className="offer-price">€{offer.price}</div>
                <a
                  href={offer.url}
                  target="_blank"
                  rel="noreferrer"
                  className="offer-link"
                >
                  Vai al negozio
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}