import Link from 'next/link'

export default function Home() {
  return (
    <main className="container page-section">

      {/* HERO */}
      <section className="hero">
  <div className="hero-content">
    <h1 className="hero-title">
      Trova il miglior prezzo.
    </h1>

    <p className="hero-sub">
      Confronta prezzi di accessori e abbigliamento moto in pochi secondi.
    </p>

    <a href="/categoria/caschi" className="primary-button">
      Inizia ora
    </a>
  </div>
</section>

      {/* CATEGORIE */}
<section className="categories">
  <h2 className="section-title">Esplora categorie</h2>

  <div className="categories-grid">

    <a href="/categoria/caschi" className="category-card">
      <h3>Caschi</h3>
      <p>Integrali, modulari, jet</p>
    </a>

    <a href="/categoria/abbigliamento" className="category-card">
      <h3>Abbigliamento</h3>
      <p>Giacche, pantaloni, guanti</p>
    </a>

    <a href="/categoria/accessori" className="category-card">
      <h3>Accessori</h3>
      <p>Valigie, elettronica, protezioni</p>
    </a>

  </div>
</section>

      {/* OFFERTE */}
      <section className="offers">
  <h2 className="section-title">Migliori offerte</h2>

  <div className="offers-grid">

    <div className="product-card">
      <h4>Shoei NXR2</h4>
      <div className="price">€465</div>
      <a href="/prodotto/casco-shoei-nxr2" className="secondary-button">
        Vedi
      </a>
    </div>

    <div className="product-card">
      <h4>AGV K6</h4>
      <div className="price">€399</div>
      <a href="#" className="secondary-button">
        Vedi
      </a>
    </div>

  </div>
</section>

    </main>
  )
}