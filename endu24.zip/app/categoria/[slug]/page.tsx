import { supabase } from '@/lib/supabase'
import Link from 'next/link'

type Props = {
  params: Promise<{ slug: string }>
  searchParams: any
}

export default async function CategoriaPage({ params, searchParams }: Props) {
  const { slug } = await params
  const { brand } = searchParams

  // 1. categoria
  const { data: category } = await supabase
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .single()

  if (!category) {
    return <div>Categoria non trovata</div>
  }

  // 2. parent
  let parent = null
  if (category.parent_id) {
    const { data } = await supabase
      .from('categories')
      .select('*')
      .eq('id', category.parent_id)
      .single()

    parent = data
  }

  // 3. sottocategorie
  const { data: children } = await supabase
    .from('categories')
    .select('*')
    .eq('parent_id', category.id)

  // 4. brands
  const { data: brands } = await supabase
    .from('brands')
    .select('*')

  // 5. query prodotti
  let query = supabase
    .from('products')
    .select('id, name, slug, image, prices, brand_id')
    .eq('category_id', category.id)

  // filtro brand
  if (brand) {
    const { data: brandData } = await supabase
      .from('brands')
      .select('id')
      .eq('slug', brand)
      .single()

    if (brandData) {
      query = query.eq('brand_id', brandData.id)
    }
  }

  const { data: products } = await query
console.log('CATEGORY:', category.id)
console.log('PRODUCTS:', products)
  // UI
  return (
    <main className="container page-section">

      {/* BREADCRUMB */}
      <div className="breadcrumb">
        <Link href="/">Home</Link>

        {parent && (
          <>
            <span>/</span>
            <Link href={`/categoria/${parent.slug}`}>
              {parent.name}
            </Link>
          </>
        )}

        <span>/</span>
        <span className="current">{category.name}</span>
      </div>

      {/* TITOLO */}
      <h1 className="category-title">{category.name}</h1>

      {/* SOTTOCATEGORIE */}
      {children?.length > 0 && (
        <>
          <h2>Sottocategorie</h2>

          <div className="subcategory-grid">
            {children.map((c) => (
              <Link
                key={c.id}
                href={`/categoria/${c.slug}`}
                className="subcategory-card"
              >
                <h3>{c.name}</h3>
                <span>Esplora →</span>
              </Link>
            ))}
          </div>
        </>
      )}

      {/* 🔥 LAYOUT FILTRI + PRODOTTI */}
      <div className="layout-grid">

        {/* FILTRI */}
        <aside className="filters">
          <h3>Filtri</h3>

          <div className="filter-group">
            <h4>Brand</h4>

            {brands?.map((b) => (
              <Link
                key={b.id}
                href={`?brand=${b.slug}`}
                className="filter-link"
              >
                {b.name}
              </Link>
            ))}
          </div>
        </aside>

        {/* PRODOTTI */}
       <div>

  <h2 className="section-title" style={{ marginTop: 0 }}>
    Prodotti
  </h2>

  {products?.length === 0 && (
    <p style={{ marginTop: 20 }}>
      Nessun prodotto trovato
    </p>
  )}

  <div className="products-grid">
    {products?.map((p) => {
      const price = p.prices?.[0]?.price

      return (
        <Link
          key={p.id}
          href={`/prodotto/${p.slug}`}
          className="product-card"
        >
          <div className="product-image">
            <img
              src={p.image || 'https://placehold.co/400'}
              alt={p.name}
            />
          </div>

          <div className="product-info">
            <h4>{p.name}</h4>

            {price && (
              <div className="price">
                €{price}
              </div>
            )}
          </div>
        </Link>
      )
    })}
  </div>

</div>

      </div>

    </main>
  )
}